from pdm.cli.commands.base import BaseCommand


class HelloCommand(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument("name")

    def handle(self, project, args):
        print(f"Hello, {args.name}!")


def main(core):
    core.register_command(HelloCommand, "hello")
